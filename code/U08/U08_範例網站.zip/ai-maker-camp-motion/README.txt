AI 小創客營｜靜態網站

請使用 HTTP 網站伺服器開啟 index.html；不支援直接雙擊 HTML。
完整資料夾直接作為網站根目錄，沒有建置步驟、不需 API 金鑰。
請維持 js/、data/、vendor/、styles.css 的相對位置。

教材、示意案例、學習單、題目、居民對話及交換表：data/content.json
Three.js：0.160.0；授權文字：vendor/THREE-LICENSE.txt
幾何模型、角色與介面為本專案原創程式繪製。

本站為教學示範；不接 AI 生成服務、不上傳作品、不代為發布作品。
進度存在瀏覽器，請使用接關碼或 JSON 備份。
