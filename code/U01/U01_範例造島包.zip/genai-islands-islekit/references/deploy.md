# 部署說明

> 只有在使用者明確同意後才部署。使用者在造島工坊選的偏好：**做完再問使用者**。
> 部署前先問：「要放到哪裡？Netlify／GitHub Pages／Cloudflare Pages／Vercel／先不要」，並說明各自需要的帳號。
> 需要登入時，請使用者自己在終端機執行登入指令，不要索取或保存密碼、token。

網站根目錄是 `site/`（裡面直接有 index.html），沒有建置步驟。專案名稱建議用 `genai-islands`。

## Netlify
- 最簡單：打開 https://app.netlify.com/drop ，把 `site` 資料夾拖進去。
- 指令：`npx netlify-cli login`（使用者自己登入）→ `npx netlify-cli deploy --dir site --prod`，第一次會詢問建立新網站。
- 免費方案的新網站右下角預設會出現「Powered by Netlify」徽章，可能蓋到網站按鈕。先問使用者要不要關；要關就到 Netlify 後台 Project configuration → General → Powered by Netlify badge 關閉（不需重新部署）。

## GitHub Pages
1. 使用者先登入：`gh auth login`。
2. 在 site 資料夾建立 repo 並推上去：
   ```
   cd site
   git init && git add . && git commit -m "first island"
   gh repo create genai-islands --public --source . --push
   ```
3. 開啟 Pages：`gh api -X POST repos/{owner}/genai-islands/pages -f "source[branch]=main" -f "source[path]=/"`（或到 repo 的 Settings → Pages 選 main）。
4. 網址：`https://<帳號>.github.io/genai-islands/`，第一次約需 1～2 分鐘。注意網站在子路徑下，所有資源要用相對路徑。

## Cloudflare Pages
- `npx wrangler login`（使用者自己登入）→ `npx wrangler pages deploy site --project-name genai-islands --branch main`。
- 新版 wrangler 第一次建立專案若失敗，依錯誤訊息先建立 Pages 專案再部署。

## Vercel
- `npx vercel login` → `npx vercel deploy site --prod`。

## 部署後必做驗證
1. 用瀏覽器或 `curl -I` 確認正式網址首頁回應 200。
2. 確認 index.html 引用的 CSS、JS 與 `data/content.json` 都回應 200（逐一檢查實際引用的檔名）。
3. 實際打開網址，點一座島，內容面板要出現；console 沒有錯誤。
4. 把正式網址、驗證結果交給使用者。

## 部署後一定要留下「部署紀錄.md」

第一次部署成功後，在**造島包資料夾最上層**（和 START_HERE.md 同一層，不是 site/ 裡面）建立 `部署紀錄.md`，讓使用者下次（或換一個 AI、換一台電腦）也能更新到同一個網址：

```
# 部署紀錄
- 正式網址：https://……
- 平台：Netlify／GitHub Pages／Cloudflare Pages／Vercel
- 專案名稱（或 Repo）：……　專案 ID：……（平台有提供才寫）
- 登入的帳號：（只寫 Email 或帳號名稱，絕對不寫密碼、token）
- 更新指令：……（下面「之後要更新」對應平台的那一行，填好實際名稱）
- 最後更新：YYYY-MM-DD
```

同時**不要刪除**平台自動產生的連結資料：`site/.netlify/`、`site/.vercel/`、`site/.git/`、`site/.wrangler/`。

## 之後要更新（重新上架到同一個網址）

使用者改內容後請你更新時：先讀 `部署紀錄.md`，修改並在本機測試，再用**同一個專案**重新部署，**不要建立新網站**（新網站會變成新網址，舊網址還是舊內容）。沒有部署紀錄時，先問使用者正式網址與平台。

| 平台 | 更新方法 |
| --- | --- |
| Netlify | `npx netlify-cli deploy --dir site --prod --site <專案名稱或 ID>`；用拖曳上架的人：Netlify 後台 → 該專案 → Deploys → 把 site 資料夾拖進頁面下方的上傳區（不要回 app.netlify.com/drop，那會開新網站） |
| GitHub Pages | `cd site` → `git add .` → `git commit -m "更新內容"` → `git push`，約 1～2 分鐘生效 |
| Cloudflare Pages | `npx wrangler pages deploy site --project-name <同一個專案名稱> --branch main` |
| Vercel | 在同一個資料夾執行 `npx vercel deploy site --prod`（會沿用 site/.vercel 的連結） |

更新後同樣做「部署後必做驗證」，並把 `部署紀錄.md` 的「最後更新」改成今天。提醒使用者看不到新內容時按 **Ctrl + F5** 強制重新整理（手機可關掉分頁重開）。
