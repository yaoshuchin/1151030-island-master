from pathlib import Path
import json,re,urllib.request
root=Path(__file__).parent
site=root/'site'
p=json.loads((root/'project.json').read_text(encoding='utf-8-sig'))
d=json.loads((site/'data/content.json').read_text(encoding='utf-8'))
checks=[]
def check(name,ok):
 checks.append({'name':name,'pass':bool(ok)})
 assert ok,name
check('網站名稱作者及中央島一致',d['site']==p['site'] and d['centerIsland']==p['centerIsland'])
check('五座島名稱與順序一致',[(s['id'],s['name']) for s in d['islands']]==[(s['id'],s['name']) for s in p['islands']])
check('教材學習單題庫完整',all(len(s['lessons'])==len(s['worksheet'])==len(s['quiz'])==3 for s in d['islands']))
check('每題正解 ID 存在且唯一',all(sum(o['id']==q['answer'] for o in q['options'])==1 and len({o['id'] for o in q['options']})==3 for s in d['islands'] for q in s['quiz']))
check('題目 ID 不重複',len({q['id'] for s in d['islands'] for q in s['quiz']})==15)
check('教材重點與學習目標保留',all(all(s[k]==src[k] for k in ['points','extra','intro','group','link']) for s,src in zip(d['islands'],p['islands'])))
check('所有居民交易配置完整',len(d['residents'])==17 and all(any(t['resident']==r['id'] for t in d['trades']) for r in d['residents']))
check('七種動物完整',len(d['animals'])==7 and {a['id'] for a in d['animals']}=={a['id'] for a in p['look']['animals']})
check('無 materials 原始檔公開',not (site/'materials').exists() and not list(site.rglob('AI小創客營_課程大綱.md')))
files=[f for f in site.rglob('*') if f.is_file()]
check('未加入 PWA',not any(f.name=='manifest.json' or 'service-worker' in f.name for f in files) and 'serviceWorker.register' not in (site/'js/app.js').read_text(encoding='utf-8'))
check('不需外部 CDN 或生成 API',not re.search(r'(?:src|href)="https?://',(site/'index.html').read_text(encoding='utf-8')) and not re.search(r'https?://',(site/'js/app.js').read_text(encoding='utf-8')))
check('未放置常見憑證檔',not any(f.suffix in ['.env','.pem','.key'] or f.name in ['credentials.json','token.json'] for f in files))
for name in ['','index.html','styles.css','js/app.js','js/scene.js','data/content.json','vendor/three.module.js','vendor/OrbitControls.js']:
 with urllib.request.urlopen('http://127.0.0.1:8768/'+name) as r:
  check('HTTP 200 '+(name or '/'),r.status==200)
out={'checks':checks,'passed':len(checks),'failed':0}
(root/'_shots/static-report.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(out,ensure_ascii=False))
