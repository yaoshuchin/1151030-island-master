@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo 請保留這個視窗，關閉視窗就會停止網站。
echo 開啟瀏覽器：http://127.0.0.1:8768
start "" "http://127.0.0.1:8768"
python -m http.server 8768 --bind 127.0.0.1 --directory site
pause
